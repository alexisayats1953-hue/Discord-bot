import discord
from discord import app_commands
from discord.ext import commands
import json
import os
import aiohttp
import asyncio

# ==========================================
#         CONFIGURACIÓN DEL BOT
# ==========================================
TOKEN = "MTQ0Mjg5MzkwNDIyMjYxNzYzMQ.Gdvzjk.OG2DvlCcc_MBf2v4XEbDRIJWKo0HkauQ93drY8" 
RAWG_API_KEY = "c4a9fe851efc4f319b60ec36a7735615" 
MI_USER_ID = 1244639297038975109 # Tu ID de Dueño

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_FILE = os.path.join(BASE_DIR, "bot_data.json")

GIF_SEPARATOR = "https://cdn.discordapp.com/attachments/1402716402456199271/1446859841158250598/nk-image-edit-sepia-xy7drk35.gif"
ROLE_ID_NOTIFY = 1387964180727992431
ADMIN_ROLE_ID = 1388289770702241913
LOG_CHANNEL_ID = 1470460261717643417

PLATFORM_STYLES = {
    "Steam":      {"color": 0x171a21, "emoji": "🚂", "thumb": "https://upload.wikimedia.org/wikipedia/commons/thumb/8/83/Steam_icon_logo.svg/512px-Steam_icon_logo.svg.png"},
    "Epic Games": {"color": 0x000000, "emoji": "🎮", "thumb": "https://upload.wikimedia.org/wikipedia/commons/thumb/3/31/Epic_Games_logo.svg/512px-Epic_Games_logo.svg.png"},
    "Netflix":    {"color": 0xe50914, "emoji": "🎬", "thumb": "https://upload.wikimedia.org/wikipedia/commons/thumb/0/08/Netflix_2015_logo.svg/512px-Netflix_2015_logo.svg.png"},
    "Valorant":   {"color": 0xff4655, "emoji": "🔫", "thumb": "https://upload.wikimedia.org/wikipedia/commons/thumb/f/fc/Valorant_logo_-_pink_color_version.svg/512px-Valorant_logo_-_pink_color_version.svg.png"}
}

ticket_track = {} 

def load_data():
    if not os.path.exists(DATA_FILE): return {"accounts_db": {}, "blacklist": []}
    with open(DATA_FILE, "r", encoding="utf-8") as f: return json.load(f)

def save_data(data):
    with open(DATA_FILE, "w", encoding="utf-8") as f: json.dump(data, f, indent=4)

async def get_game_image(game_name):
    url = f"https://api.rawg.io/api/games?key={RAWG_API_KEY}&search={game_name}"
    async with aiohttp.ClientSession() as session:
        async with session.get(url) as resp:
            if resp.status == 200:
                data = await resp.json()
                if data['results']: return data['results'][0]['background_image']
    return None

# ==========================================
#         SISTEMA DE TICKETS
# ==========================================
class TicketControl(discord.ui.View):
    def __init__(self, original_msg_id):
        super().__init__(timeout=None)
        self.original_msg_id = original_msg_id

    @discord.ui.button(label="1. Enviar Datos", style=discord.ButtonStyle.primary, emoji="📝", custom_id="tk_data_v2")
    async def send_data(self, it: discord.Interaction, button: discord.ui.Button):
        modal = discord.ui.Modal(title="Verificación de Cuenta")
        u_input = discord.ui.TextInput(label="Usuario", placeholder="Usuario de la cuenta...")
        p_input = discord.ui.TextInput(label="Contraseña", placeholder="Contraseña de la cuenta...")
        modal.add_item(u_input); modal.add_item(p_input)
        
        async def callback(it2: discord.Interaction):
            db = load_data()
            msg_id = str(self.original_msg_id)
            if msg_id in db["accounts_db"]:
                correct_acc = db["accounts_db"][msg_id]["accounts"][0]
                if u_input.value.strip() == correct_acc["u"] and p_input.value.strip() == correct_acc["p"]:
                    user_data_str = f"**User:** `{u_input.value}`\n**Pass:** `{p_input.value}`"
                    ticket_track[it2.channel.id] = {"data": user_data_str, "status": "waiting_photo"}
                    await it2.response.send_message("✅ **Datos verificados.** Sube la FOTO del error.", ephemeral=False)
                    button.disabled = True
                    await it2.edit_original_response(view=self)
                else:
                    await it2.response.send_message("❌ Datos incorrectos.", ephemeral=True)
        modal.on_submit = callback
        await it.response.send_modal(modal)

    @discord.ui.button(label="Cerrar Ticket", style=discord.ButtonStyle.danger, emoji="🔒", custom_id="tk_close_owner")
    async def close_btn(self, it: discord.Interaction, b):
        if it.user.id != MI_USER_ID: return
        await it.response.send_message("🗑️ Cerrando..."); await asyncio.sleep(2); await it.channel.delete()

class ConfirmarReporteView(discord.ui.View):
    def __init__(self, original_msg_id):
        super().__init__(timeout=60)
        self.original_msg_id = original_msg_id

    @discord.ui.button(label="Sí", style=discord.ButtonStyle.success, emoji="✅")
    async def confirm(self, it: discord.Interaction, b):
        thread = await it.channel.create_thread(name=f"🆘-reporte-{it.user.name}", type=discord.ChannelType.private_thread)
        await thread.add_user(it.user)
        emb = discord.Embed(title="🆘 SISTEMA DE REPORTE", description="Verifica tu cuenta y sube la foto.", color=0xFF0000)
        await thread.send(content=f"🔔 <@{MI_USER_ID}>", embed=emb, view=TicketControl(self.original_msg_id))
        await it.response.edit_message(content=f"✅ Ticket en {thread.mention}", view=None)

    @discord.ui.button(label="No", style=discord.ButtonStyle.danger, emoji="❌")
    async def cancel(self, it: discord.Interaction, b):
        await it.response.edit_message(content="❌ Cancelado.", view=None)

# ==========================================
#         VISTA DE POST PÚBLICO
# ==========================================
class PublicPostView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label="Ver Acceso", style=discord.ButtonStyle.primary, custom_id="btn_acc_main", emoji="🔒")
    async def ver_acceso(self, it, b):
        db = load_data(); msg_id = str(it.message.id)
        if it.user.id in db.get("blacklist", []): return
        if msg_id not in db["accounts_db"]: return
        cuenta = db["accounts_db"][msg_id]["accounts"][0]
        await it.response.send_message(embed=discord.Embed(title="🔑 ACCESO", description=f"`{cuenta['u']}:{cuenta['p']}`", color=0x00FF00), ephemeral=True)

    @discord.ui.button(label="Reportar", style=discord.ButtonStyle.danger, custom_id="btn_rep_main", emoji="⚠️")
    async def reportar(self, it, b):
        await it.response.send_message("¿seguro que quieres abrir ticket 🎫?", view=ConfirmarReporteView(it.message.id), ephemeral=True)

# ==========================================
#         PANEL DE EDICIÓN
# ==========================================
class PanelEdicion(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)
        self.titulo = "Stock"; self.plataforma = "Steam"; self.juegos = "..."; self.datos = []; self.imagen = None
        self.actual = 5; self.maximo = 100

    def generar_embed(self, disponible=True):
        style = PLATFORM_STYLES.get(self.plataforma, PLATFORM_STYLES["Steam"])
        status = "✅ DISPONIBLE" if disponible else "❌ AGOTADO"
        color = style["color"] if disponible else 0x2f3136
        desc = (f"📁 **Plataforma:** {self.plataforma}\n"
                f"👤 **Estado:** {'En Stock' if disponible else 'Agotado'}\n"
                f"📦 **Stock:** `{self.actual}/{self.maximo}`\n\n"
                f"🎮 **CONTENIDO:**\n{self.juegos}\n\n"
                f"🌐 [S4GM STORE](https://s4gm.store)")
        emb = discord.Embed(title=f"{status} | {self.titulo}", description=desc, color=color)
        emb.set_thumbnail(url=style["thumb"])
        if self.imagen: emb.set_image(url=self.imagen)
        return emb

    @discord.ui.button(label="Ajustar Stock (N/N)", style=discord.ButtonStyle.secondary, emoji="📦")
    async def ed_st(self, it, b):
        modal = discord.ui.Modal(title="Ajustar Stock"); inp = discord.ui.TextInput(label="Formato: actual/maximo", placeholder="Ejemplo: 5/100"); modal.add_item(inp)
        async def cb(it2):
            try:
                a, m = map(int, inp.value.split("/"))
                self.actual, self.maximo = a, m
                await it2.response.edit_message(embed=self.generar_embed())
            except: await it2.response.send_message("Formato inválido. Usa: 5/100", ephemeral=True)
        modal.on_submit = cb; await it.response.send_modal(modal)

    @discord.ui.select(placeholder="📁 Plataforma", options=[discord.SelectOption(label=k, emoji=v["emoji"]) for k,v in PLATFORM_STYLES.items()])
    async def sel(self, it, s): self.plataforma = s.values[0]; await it.response.edit_message(embed=self.generar_embed())

    @discord.ui.button(label="Juegos", style=discord.ButtonStyle.secondary, emoji="🎮")
    async def ed_j(self, it, b):
        modal = discord.ui.Modal(title="Juegos"); inp = discord.ui.TextInput(label="Lista", style=discord.TextStyle.long); modal.add_item(inp)
        async def cb(it2): self.juegos = inp.value; await it2.response.edit_message(embed=self.generar_embed())
        modal.on_submit = cb; await it.response.send_modal(modal)

    @discord.ui.button(label="Cargar Cuenta", style=discord.ButtonStyle.primary, emoji="📝")
    async def ed_c(self, it, b):
        modal = discord.ui.Modal(title="Datos"); inp = discord.ui.TextInput(label="u:p"); modal.add_item(inp)
        async def cb(it2):
            if ":" in inp.value: self.datos = [{"u": inp.value.split(":")[0].strip(), "p": inp.value.split(":")[1].strip()}]
            await it2.response.edit_message(embed=self.generar_embed())
        modal.on_submit = cb; await it.response.send_modal(modal)

    @discord.ui.button(label="Imagen RAWG", style=discord.ButtonStyle.secondary, emoji="🖼️")
    async def ed_img(self, it, b):
        modal = discord.ui.Modal(title="RAWG"); inp = discord.ui.TextInput(label="Juego"); modal.add_item(inp)
        async def cb(it2):
            img = await get_game_image(inp.value); self.imagen = img if img else self.imagen
            await it2.response.edit_message(embed=self.generar_embed())
        modal.on_submit = cb; await it.response.send_modal(modal)

    @discord.ui.button(label="🚀 PUBLICAR", style=discord.ButtonStyle.success)
    async def pub(self, it, b):
        if not self.datos: return await it.response.send_message("❌ Pon la cuenta", ephemeral=True)
        msg = await it.channel.send(content=f"<@&{ROLE_ID_NOTIFY}>", embed=self.generar_embed(), view=PublicPostView())
        await it.channel.send(GIF_SEPARATOR)
        db = load_data()
        db["accounts_db"][str(msg.id)] = {
            "accounts": self.datos, 
            "raw_data": {"t": self.titulo, "p": self.plataforma, "j": self.juegos, "i": self.imagen, "st_a": self.actual, "st_m": self.maximo}
        }
        save_data(db); await it.response.edit_message(content="✅ Publicado", embed=None, view=None)

# ==========================================
#         COMANDOS DE ACTUALIZACIÓN
# ==========================================
class MyBot(commands.Bot):
    def __init__(self):
        super().__init__(command_prefix="!", intents=discord.Intents.all())
    async def setup_hook(self):
        self.add_view(PublicPostView())

bot = MyBot()

@bot.tree.command(name="actualizar_stock", description="Actualiza el número de stock de un embed")
async def update_stock(it: discord.Interaction, message_id: str, actual: int, maximo: int):
    if not any(r.id == ADMIN_ROLE_ID for r in it.user.roles): return
    db = load_data()
    if message_id not in db["accounts_db"]:
        return await it.response.send_message("❌ Mensaje no encontrado en DB.", ephemeral=True)
    
    try:
        msg = await it.channel.fetch_message(int(message_id))
        info = db["accounts_db"][message_id]["raw_data"]
        # Actualizamos la DB
        info["st_a"] = actual
        info["st_m"] = maximo
        save_data(db)
        
        # Re-generamos el embed con el nuevo stock
        style = PLATFORM_STYLES.get(info["p"], PLATFORM_STYLES["Steam"])
        color = style["color"] if actual > 0 else 0x2f3136
        status = "✅ DISPONIBLE" if actual > 0 else "❌ AGOTADO"
        
        desc = (f"📁 **Plataforma:** {info['p']}\n"
                f"👤 **Estado:** {'En Stock' if actual > 0 else 'Agotado'}\n"
                f"📦 **Stock:** `{actual}/{maximo}`\n\n"
                f"🎮 **CONTENIDO:**\n{info['j']}\n\n"
                f"🌐 [S4GM STORE](https://s4gm.store)")
        
        new_embed = discord.Embed(title=f"{status} | {info['t']}", description=desc, color=color)
        new_embed.set_thumbnail(url=style["thumb"])
        if info['i']: new_embed.set_image(url=info['i'])
        
        await msg.edit(embed=new_embed, view=PublicPostView() if actual > 0 else None)
        await it.response.send_message(f"✅ Stock actualizado a `{actual}/{maximo}`", ephemeral=True)
    except Exception as e:
        await it.response.send_message(f"❌ Error: {e}", ephemeral=True)

# (Resto de eventos on_message, status, etc. se mantienen igual...)
@bot.event
async def on_message(message):
    if message.author.bot: return
    if isinstance(message.channel, discord.Thread) and "🆘-reporte-" in message.channel.name:
        if message.channel.id in ticket_track and ticket_track[message.channel.id]["status"] == "waiting_photo":
            if message.attachments:
                for a in message.attachments:
                    if any(a.filename.lower().endswith(e) for e in ['png', 'jpg', 'jpeg', 'gif']):
                        await message.add_reaction("📸")
                        info = ticket_track[message.channel.id]
                        log_ch = bot.get_channel(LOG_CHANNEL_ID)
                        log_emb = discord.Embed(title="🚨 REPORTE VERIFICADO", color=0x00FF00)
                        log_emb.add_field(name="👤 Cliente", value=f"{message.author.mention}", inline=True)
                        log_emb.add_field(name="🔐 Datos Validados", value=info["data"], inline=False)
                        log_emb.set_image(url=a.url)
                        await log_ch.send(content=f"🔔 <@{MI_USER_ID}>", embed=log_emb)
                        await message.channel.send("✅ Log enviado. Cerrando en 8s...")
                        del ticket_track[message.channel.id]
                        await asyncio.sleep(8); await message.channel.delete(); break
    await bot.process_commands(message)

@bot.tree.command(name="embed")
async def cmd_embed(it):
    if any(r.id == ADMIN_ROLE_ID for r in it.user.roles):
        await it.response.send_message(embed=PanelEdicion().generar_embed(), view=PanelEdicion(), ephemeral=True)

@bot.event
async def on_ready():
    await bot.tree.sync()
    print(f"✅ Bot Online: {bot.user}")

bot.run("MTQ0Mjg5MzkwNDIyMjYxNzYzMQ.Gdvzjk.OG2DvlCcc_MBf2v4XEbDRIJWKo0HkauQ93drY8")

